package sorting.service;

import java.util.List;

public interface Loader {
    List<String> load(String fileName);
}
