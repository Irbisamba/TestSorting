package sorting;

import sorting.service.Loader;
import sorting.service.LoaderImpl;
import sorting.service.WriterImpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;

import static java.util.stream.Collectors.toList;

public class TestSorting {
    public static void main(String[] args) throws IOException {
        TestSorting testSorting  = new TestSorting();

        List<String> firstSorting = sortByNaturalOrdering("file.txt", "sorted1.txt");
        List<String> secondSorting = sortByStringLenght("file.txt", "sorted2.txt");
        List<String> thirddSorting = testSorting.sortByQuantityInput("file.txt", "sorted3.txt");

    }
    public static List<String> sortByNaturalOrdering(String fileFrom, String fileTo) {
        LoaderImpl loader = new LoaderImpl();
        WriterImpl writer = new WriterImpl();
        List<String> stringList = loader.load(fileFrom);
        Collections.sort(stringList);
        writer.write(stringList, fileTo);
        return stringList;
    }

    public static List<String> sortByStringLenght(String fileFrom, String fileTo) {
        LoaderImpl loader = new LoaderImpl();
        WriterImpl writer = new WriterImpl();
        List<String> stringList = loader.load(fileFrom);
        Comparator comparator = new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                String s1 = (String) o1;
                String s2 = (String) o2;
                if(s1.length()==s2.length())
                    return 0;
                if(s1.length()>s2.length())
                    return 1;
                if(s1.length()<s2.length())
                    return -1;
                return 0;
            }
        };
        Collections.sort(stringList, comparator);
        writer.write(stringList, fileTo);
        return stringList;
    }

    public List<String> sortByQuantityInput(String fileFrom, String fileTo) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Введите число ");
        int number = Integer.parseInt(reader.readLine());
        LoaderImpl loader = new LoaderImpl();
        WriterImpl writer = new WriterImpl();
        List<String> stringList = loader.load(fileFrom);
        List<String[]> listOfArrays = new ArrayList<>();
        List<String> resultList = new ArrayList<>();
        for(String s : stringList) {
            String [] array = s.split(" ");
            listOfArrays.add(array);
        }
        for(int i = 0; i < listOfArrays.size(); i++) {
            int outerCounter = 0;
            for(int j = 0; j < listOfArrays.size(); j++) {

                if(listOfArrays.get(i)[number-1].equals(listOfArrays.get(j)[number-1])) {
                    outerCounter++; }
            }

            StringBuilder stringBuilder = new StringBuilder(stringList.get(i));
            stringBuilder.append(" " + outerCounter);
            resultList.add(stringBuilder.toString());
        }

        resultList = resultList.stream()
                .map(s->reverse(s))
                .sorted()
                .map(s->reverse(s))
                .collect(toList());

        for(String s : resultList) {
            System.out.println(s);
        }
        writer.write(resultList, fileTo);
        return resultList;
    }

    private String reverse(String d){
        return new StringBuilder(d).reverse().toString();
    }

}
